export default {
  getMarkers: 'https://www.yanyujiangnan.com.cn/mod/map/js/provinces.json',
  getMarkers2:'http://59.110.174.5/regions.json',
  getMarkers3: 'http://59.110.174.5/weather/data.json'
}
//两个json格式中经纬度位置相反，替换时注意改变经纬度